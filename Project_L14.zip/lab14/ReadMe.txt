L14 - 12/12/2025
Grec Carina-Gabriela 1241EA
Dumitru Vlad-Andrei 1241EA