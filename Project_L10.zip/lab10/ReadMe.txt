17.12.2025 
Grec Carina-Gabriela 1241EA
Dan Maria-Andrada 1241EA