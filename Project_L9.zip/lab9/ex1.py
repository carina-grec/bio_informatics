#1. Make an artificial DNA sequence of 200-400b in length, in which to simulate 3-4 transposable elements.
import random
def generate_dna_sequence(length):
    return ''.join(random.choices('ACGT', k=length))
def insert_transposable_elements(dna_sequence, elements):
    for element in elements:
        position = random.randint(0, len(dna_sequence))
        dna_sequence = dna_sequence[:position] + element + dna_sequence[position:]
    return dna_sequence
dna_length = random.randint(200, 400)
dna_sequence = generate_dna_sequence(dna_length)
#some transposable elements
transposable_elements = ['ATCGATCG', 'GGTACC', 'TTAAGGCC', 'CCGGAATT']
modified_dna_sequence = insert_transposable_elements(dna_sequence, transposable_elements)
print("Modified DNA Sequence:", modified_dna_sequence)

#2. Implement a software application to detect the positions of these transposable elements (start, end) within the created DNA sequence. Note: Intersect two or three transposons to see how the algorithm behaves in such situations.
def find_transposable_elements(dna_sequence, elements):
    positions = {}
    for element in elements:
        start = 0
        while True:
            start = dna_sequence.find(element, start)
            if start == -1:
                break
            end = start + len(element) - 1
            if element not in positions:
                positions[element] = []
            positions[element].append((start, end))
            start += 1  # Move to the next character to find overlapping elements
    return positions
detected_positions = find_transposable_elements(modified_dna_sequence, transposable_elements)
print("Detected Transposable Elements Positions:")
for element, pos_list in detected_positions.items():
    for pos in pos_list:
        print(f"Element: {element}, Start: {pos[0]}, End: {pos[1]}")

#3.Import the 3 sequences of genomes fasta files. Use these as an input for your app and modify your app in order to be able to handle the input size. The app must detect transposable elements and results from the output must show their position and length. Note that the inverted repeats are unknown and must be detected. Note that the minimum size of the inverted repeats must be o 5 bases and the maximum must be of 6 bases. Note: The following must be taken into consideration: 1) transposone embedding, 2) transponsone overlapping.
from Bio import SeqIO

def find_inverted_repeats(dna_sequence, min_size=5, max_size=6):
    inverted_repeats = []
    length = len(dna_sequence)
    for size in range(min_size, max_size + 1):
        for i in range(length - size + 1):
            repeat = dna_sequence[i:i + size]
            rev_comp = repeat[::-1].translate(str.maketrans('ACGT', 'TGCA'))
            for j in range(i + size, length - size + 1):
                if dna_sequence[j:j + size] == rev_comp:
                    inverted_repeats.append((i, j + size - 1))
    return inverted_repeats


def analyze_fasta_file(file_path, transposable_elements):
    for record in SeqIO.parse(file_path, "fasta"):
        dna_sequence = str(record.seq)
        print(f"Analyzing sequence: {record.id}")

        detected_positions = find_transposable_elements(dna_sequence, transposable_elements)

        for element, pos_list in detected_positions.items():
            for pos in pos_list:
                length = pos[1] - pos[0] + 1
                print(f"Element: {element}, Start: {pos[0]}, End: {pos[1]}, Length: {length}")
        inverted_repeats = find_inverted_repeats(dna_sequence)
        for ir in inverted_repeats:
            length = ir[1] - ir[0] + 1
            print(f"Inverted Repeat: Start: {ir[0]}, End: {ir[1]}, Length: {length}")


fasta_files = ['sequence.fasta', 'sequence(1).fasta', 'sequence(2).fasta']

for fasta_file in fasta_files:
    analyze_fasta_file(fasta_file, transposable_elements)



