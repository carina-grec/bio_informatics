#Download from the NCBI website the FASTA files containing the covid-19 genome and teh influenza genome. Use the AI to compare the codon frequencies between the two.
#a) Make a chart that shows the top 10 most frequent codons for covid-19.
#b) Make a chart that shows the top 10 most frequent codons for influenza.
#c) Compare the two results and show the most frequente codons between the two.
#d) Show in the output of the console the top 3 aminoacidesfor each genome.
#Note that each codon has an ssociated amino acid. Thus top 3 codons show the top 3 amino acids.
#e) Formulate a promt in which you as the AI which foods lack the 3 amino acids.
import os
import re
from collections import Counter
import matplotlib.pyplot as plt

COVID_FASTA = "covid.fasta"  

OUT_DIR = "codon_usage_covid_only_output"
os.makedirs(OUT_DIR, exist_ok=True)
COVID_PNG = os.path.join(OUT_DIR, "top10_codons_covid.png")

CODON_TO_AA = {
    "UUU":"F","UUC":"F","UUA":"L","UUG":"L","CUU":"L","CUC":"L","CUA":"L","CUG":"L",
    "AUU":"I","AUC":"I","AUA":"I","AUG":"M","GUU":"V","GUC":"V","GUA":"V","GUG":"V",
    "UCU":"S","UCC":"S","UCA":"S","UCG":"S","AGU":"S","AGC":"S","CCU":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACU":"T","ACC":"T","ACA":"T","ACG":"T","GCU":"A","GCC":"A","GCA":"A","GCG":"A",
    "UAU":"Y","UAC":"Y","CAU":"H","CAC":"H","CAA":"Q","CAG":"Q","AAU":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAU":"D","GAC":"D","GAA":"E","GAG":"E","UGU":"C","UGC":"C","UGG":"W",
    "CGU":"R","CGC":"R","CGA":"R","CGG":"R","AGA":"R","AGG":"R","GGU":"G","GGC":"G","GGA":"G","GGG":"G",
    "UAA":"*","UAG":"*","UGA":"*"
}
AA_NAME = {
    'A':'Alanine','R':'Arginine','N':'Asparagine','D':'Aspartic acid','C':'Cysteine',
    'Q':'Glutamine','E':'Glutamic acid','G':'Glycine','H':'Histidine','I':'Isoleucine',
    'L':'Leucine','K':'Lysine','M':'Methionine','F':'Phenylalanine','P':'Proline',
    'S':'Serine','T':'Threonine','W':'Tryptophan','Y':'Tyrosine','V':'Valine','*':'Stop'
}

def read_fasta_concat(path: str) -> str:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"FASTA not found: {path}")
    seq_lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith(">"):
                continue
            seq_lines.append(line.strip())
    seq = "".join(seq_lines).upper()
    seq = re.sub(r"[^ACGTU]", "", seq).replace("T", "U")
    return seq

def count_codons(seq: str) -> Counter:
    end = (len(seq) // 3) * 3
    c = Counter()
    for i in range(0, end, 3):
        codon = seq[i:i+3]
        if len(codon) == 3 and re.fullmatch(r"[ACGU]{3}", codon):
            c[codon] += 1
    return c

def top_n(counter: Counter, n=10):
    return counter.most_common(n)

def plot_top10(counter: Counter, title: str, outfile: str):
    top10 = top_n(counter, 10)
    labels = [codon for codon, _ in top10]
    values = [cnt for _, cnt in top10]
    plt.figure(figsize=(10, 5))
    plt.bar(labels, values)  
    plt.title(title)
    plt.xlabel("Codon")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(outfile, dpi=150)
    plt.close()

def aa_of_codon(codon: str) -> str:
    return CODON_TO_AA.get(codon, "?")

def print_top3_amino_acids(counter: Counter, label: str):
    top3 = top_n(counter, 3)
    print(f"\n{label} — Top 3 amino acids (by top 3 codons):")
    for i, (codon, _) in enumerate(top3, start=1):
        aa = aa_of_codon(codon)
        name = "Stop" if aa == "*" else AA_NAME.get(aa, aa)
        print(f"{i}. {name} (codon {codon})")

def main():
    print("Reading covid.fasta ...")
    covid_seq = read_fasta_concat(COVID_FASTA)
    print("Counting codons (frame 0) ...")
    covid_counts = count_codons(covid_seq)
    total = sum(covid_counts.values())
    print(f"Total codons counted (COVID): {total}")

    # (a) 
    plot_top10(covid_counts, "Top 10 codons COVID-19 (frame 0, full genome)", COVID_PNG)
    print(f"Saved chart: {COVID_PNG}")

    # (b) & (c) 
    print("\nGenerated")

    # (d)
    print_top3_amino_acids(covid_counts, "COVID-19 genome")
    print("\nCOVID-19 — Top 10 codons (codon, count, amino_acid):")
    for codon, cnt in top_n(covid_counts, 10):
        aa = aa_of_codon(codon)
        name = "Stop" if aa == "*" else AA_NAME.get(aa, aa)
        print(f"{codon:>3}  {cnt:>8}  {name}")

if __name__ == "__main__":
    main()