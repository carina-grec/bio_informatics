Grec Carina-Gabriela
