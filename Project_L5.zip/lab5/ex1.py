#1. Take an arbitrary DNA sequence from the NCBI (National Center for Biotechnology), between 1000 and 3000 nucleotides (letters).
#2. Take 2000 random samples from this sequence, of about 100-150 bases.
#3. Store these samples in an array.
#4. Rebuild the original DNA sequence using these random samples
#5. Make a testfile called answers.txt in which you explain what will be the main issue with the alg approach.

import random

def read_fasta(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
    return sequence

def take_random_samples(sequence, num_samples=2000, min_length=100, max_length=150):
    samples = []
    seq_length = len(sequence)
    for _ in range(num_samples):
        start = random.randint(0, seq_length - max_length)
        length = random.randint(min_length, max_length)
        sample = sequence[start:start + length]
        samples.append(sample)
    return samples

def rebuild_sequence(samples):  
    reconstructed = ''
    for sample in samples:
        reconstructed += sample
    return reconstructed

def main(): 
    fasta_file = 'covid.fasta'  
    original_sequence = read_fasta(fasta_file)
    
    samples = take_random_samples(original_sequence)
    
    reconstructed_sequence = rebuild_sequence(samples)
    
    with open('answers.txt', 'w') as f:
        f.write("The main issue with this approach is that the random samples may not cover the entire original sequence uniformly. "
                "Some regions may be overrepresented while others may be underrepresented or missing entirely. "
                "Additionally, since the samples are taken randomly, there may be overlaps and gaps that make it impossible to accurately reconstruct the original sequence.")
    
    print("Original Sequence Length:", len(original_sequence))
    print("Reconstructed Sequence Length:", len(reconstructed_sequence))
    print("Samples taken:", len(samples))
    print("Explanation written to answers.txt")

if __name__ == "__main__":
    main()