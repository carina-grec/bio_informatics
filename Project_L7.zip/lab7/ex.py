#1) Take an arbitrary DNA sequence from the NCBI between 1000 and 3000 nucleotides (letters)
#2) Implement a software application that detects repetitions (between 6b and 10b) in this DNA sequence.
import matplotlib.pyplot as plt
import os

def find_repetitions(dna_sequence, min_length=6, max_length=10):
    repetitions = {}
    seq_length = len(dna_sequence)

    for length in range(min_length, max_length + 1):
        for i in range(seq_length - length + 1):
            substring = dna_sequence[i:i + length]
            if substring in repetitions:
                repetitions[substring] += 1
            else:
                repetitions[substring] = 1

    repetitions = {k: v for k, v in repetitions.items() if v > 1}
    return repetitions

with open('file.fasta', 'r') as file:
    lines = file.readlines()
    dna_sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
    repetitions = find_repetitions(dna_sequence)
    for seq, count in repetitions.items():
        print(f"Sequence: {seq}, Count: {count}")


#3) Plot the frequencies of the repetitions found.
    if repetitions:
        sequences = list(repetitions.keys())
        counts = list(repetitions.values())

        plt.figure(figsize=(10, 6))
        plt.bar(sequences, counts, color='skyblue')
        plt.xlabel('Repetitive Sequences')
        plt.ylabel('Frequencies')
        plt.title('Frequencies of Repetitive Sequences in DNA')
        plt.xticks(rotation=90)
        plt.tight_layout()
        plt.show()
    else:
        print("No repetitions found.")

#4)For each of the 10 genomes from the folder called "10 genomes", plot the frequencies of the repetitions found.
genome_folder = '10 genomes'
for genome_file in os.listdir(genome_folder):
    if genome_file.endswith('.fasta'):
        with open(os.path.join(genome_folder, genome_file), 'r') as file:
            lines = file.readlines()
            dna_sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
            repetitions = find_repetitions(dna_sequence)
            if repetitions:
                sequences = list(repetitions.keys())
                counts = list(repetitions.values())

                plt.figure(figsize=(10, 6))
                plt.bar(sequences, counts, color='lightgreen')
                plt.xlabel('Repetitive Sequences')
                plt.ylabel('Frequencies')
                plt.title(f'Frequencies of Repetitive Sequences in {genome_file}')
                plt.xticks(rotation=90)
                plt.tight_layout()
                plt.show()
            else:
                print(f"No repetitions found in {genome_file}.")

def main():
    plt.show()









