#A square matrix of an arbitrary size and the corresponding initial vector are given. Implement a software application that makes a prediction on a total of 5 discrete steps, using this matrix and the corresponding vector.

import numpy as np

class StatePredictor:
    def __init__(self, transition_matrix, initial_vector):
        self.T = np.asarray(transition_matrix, dtype=float)
        self.x0 = np.asarray(initial_vector, dtype=float)
        self._validate_inputs()

    def _validate_inputs(self):
        rows, cols = self.T.shape
        if rows != cols:
            raise ValueError("Input must be a square matrix.")
        if self.x0.shape[0] != cols:
            raise ValueError("Vector size must match matrix dimensions.")

    def predict(self, steps=5, verbose=True):
        state = self.x0.copy()
        history = []

        if verbose:
            print(f"Initial State (t=0): {state}")

        for t in range(steps):
            state = self.T @ state 
            history.append(state.copy())

            if verbose:
                print(f"Step {t + 1}: {state}")

        return history

def main():
    input_matrix = [
        [0.7, 0.2, 0.1],
        [0.4, 0.5, 0.1],
        [0.2, 0.6, 0.2]
    ]
    initial_v = [0.0, 1.0, 0.0]

    print("Prediction: ")
    try:
        predictor = StatePredictor(input_matrix, initial_v)
        _ = predictor.predict(steps=5, verbose=True)
    except ValueError as err:
        print(f"Error: {err}")

if __name__ == "__main__":
    main()
