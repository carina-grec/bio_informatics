#Use a DNA sequence of 50 letters in order to calculate the transition matrix that represent the sequence and store it in a json file.  

import tkinter as tk
from tkinter import messagebox
import numpy as np
import json
import random

BASES = ("A", "C", "G", "T")

def validate_dna(seq: str, required_len: int = 50) -> str:
    s = seq.strip().upper()
    if len(s) != required_len:
        raise ValueError(f"DNA sequence must have exactly {required_len} letters (got {len(s)}).")
    bad = sorted(set(ch for ch in s if ch not in BASES))
    if bad:
        raise ValueError(f"Invalid characters in DNA: {bad}. Allowed: {list(BASES)}")
    return s

def build_transition_matrix(seq: str, alphabet=BASES) -> np.ndarray:
    idx = {b: i for i, b in enumerate(alphabet)}
    counts = np.zeros((len(alphabet), len(alphabet)), dtype=float)

    for a, b in zip(seq[:-1], seq[1:]):
        counts[idx[a], idx[b]] += 1

    row_sums = counts.sum(axis=1, keepdims=True)
    probs = np.divide(counts, row_sums, out=np.zeros_like(counts), where=row_sums != 0)

    for i in range(len(alphabet)):
        if row_sums[i, 0] == 0:
            probs[i, i] = 1.0

    return probs

def save_matrix_json(matrix: np.ndarray, path: str = "dna_matrix.json"):
    payload = {
        "alphabet": list(BASES),
        "transition_matrix": matrix.tolist(),
        "definition": "M[i][j] = P(next=alphabet[j] | current=alphabet[i])"
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

class StatePredictor:
    def __init__(self, matrix: np.ndarray):
        self.M = np.asarray(matrix, dtype=float)

    def run(self, initial_state, steps: int = 5):
        state = np.asarray(initial_state, dtype=float)
        out = []
        for _ in range(steps):
            state = self.M.T @ state  
            out.append(state.copy())
        return out

class SequenceSynthesizer:
    def __init__(self, matrix: np.ndarray, alphabet=BASES):
        self.M = np.asarray(matrix, dtype=float)
        self.alphabet = list(alphabet)

    def sample(self, length: int = 50) -> str:
        cur = random.randrange(len(self.alphabet))
        seq = [self.alphabet[cur]]

        for _ in range(length - 1):
            probs = self.M[cur]  
            nxt = np.random.choice(len(self.alphabet), p=probs)
            seq.append(self.alphabet[nxt])
            cur = nxt

        return "".join(seq)

class DnaToolApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ex1: DNA Analyzer & Synthesizer")
        self.geometry("650x700")

        self.matrix = None
        self.seq_box = self._make_section(
            "1. Input Data",
            button_text="Generate Random DNA (50 chars)",
            button_cmd=self.on_generate_dna,
            text_height=2
        )

        self.mat_box = self._make_section(
            "2. Transition Matrix (JSON)",
            button_text="Compute & Save Matrix",
            button_cmd=self.on_compute_matrix,
            text_height=6
        )

        self.pred_box = self._make_section(
            "3. State Prediction (Distribution)",
            button_text="Predict Next 5 Steps (Start: 100% A)",
            button_cmd=self.on_predict,
            text_height=6
        )

        self.syn_box = self._make_section(
            "4. Synthesize New Sequence",
            button_text="Generate New DNA from Matrix",
            button_cmd=self.on_synthesize,
            text_height=3
        )
        self.syn_box.config(fg="blue")

    def _make_section(self, title, button_text, button_cmd, text_height=4):
        frame = tk.LabelFrame(self, text=title, padx=10, pady=10)
        frame.pack(fill="x", padx=10, pady=6)

        tk.Button(frame, text=button_text, command=button_cmd).pack(anchor="w")
        box = tk.Text(frame, height=text_height, width=70)
        box.pack(pady=6)
        return box

    def on_generate_dna(self):
        dna = "".join(random.choice("ACGT") for _ in range(50))
        self.seq_box.delete("1.0", tk.END)
        self.seq_box.insert(tk.END, dna)

    def on_compute_matrix(self):
        try:
            seq = validate_dna(self.seq_box.get("1.0", tk.END))
            self.matrix = build_transition_matrix(seq)
            save_matrix_json(self.matrix, "dna_matrix.json")
        except ValueError as e:
            messagebox.showerror("Input error", str(e))
            return

        self.mat_box.delete("1.0", tk.END)
        for row in self.matrix:
            self.mat_box.insert(tk.END, f"{[round(x, 2) for x in row]}\n")

        messagebox.showinfo("Success", "Matrix computed and saved to dna_matrix.json")

    def on_predict(self):
        if self.matrix is None:
            messagebox.showwarning("Missing data", "Compute the transition matrix first.")
            return

        predictor = StatePredictor(self.matrix)
        initial = [1.0, 0.0, 0.0, 0.0]  # 100% A
        results = predictor.run(initial, steps=5)

        self.pred_box.delete("1.0", tk.END)
        for i, vec in enumerate(results, start=1):
            self.pred_box.insert(tk.END, f"Step {i}: {[round(v, 3) for v in vec]}\n")

    def on_synthesize(self):
        if self.matrix is None:
            messagebox.showwarning("Missing data", "Compute the transition matrix first.")
            return

        gen = SequenceSynthesizer(self.matrix)
        new_seq = gen.sample(length=50)

        self.syn_box.delete("1.0", tk.END)
        self.syn_box.insert(tk.END, new_seq)


if __name__ == "__main__":
    app = DnaToolApp()
    app.mainloop()
