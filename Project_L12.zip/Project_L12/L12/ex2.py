#Use an English text of a length of 300 letters and calculate the transition probabilities between the words. Store  that as a json file. Represent each new word with one unique symbol.

import tkinter as tk
from tkinter import messagebox
import numpy as np
import json
import random
import re

def tokenize(text: str):
    cleaned = re.sub(r"[^A-Za-z0-9\s]+", " ", text).lower()
    return [w for w in cleaned.split() if w]

def build_vocab(words):
    vocab = sorted(set(words))
    word_to_id = {w: i for i, w in enumerate(vocab)}
    symbol_map = {w: f"W{i}" for w, i in word_to_id.items()}
    return vocab, word_to_id, symbol_map

def make_transition(words, word_to_id, n):
    counts = np.zeros((n, n), dtype=float)
    for cur, nxt in zip(words[:-1], words[1:]):
        c = word_to_id[cur]
        r = word_to_id[nxt]
        counts[r, c] += 1

    P = np.zeros((n, n), dtype=float)
    col_sums = counts.sum(axis=0)

    for c in range(n):
        if col_sums[c] > 0:
            P[:, c] = counts[:, c] / col_sums[c]
        else:
            P[c, c] = 1.0  
    return P

def save_json(path, text, vocab, symbols, matrix):
    payload = {
        "text_length_chars": len(text),
        "vocabulary_size": len(vocab),
        "symbol_mapping": symbols,          
        "matrix": matrix.tolist(),
        "matrix_definition": "matrix[next_index][current_index] = P(next | current)",
        "vocabulary_order": vocab
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

class DistributionPredictor:
    def __init__(self, P: np.ndarray):
        self.P = np.asarray(P, dtype=float)

    def steps(self, v0, k=5):
        v = np.asarray(v0, dtype=float)
        out = []
        for _ in range(k):
            v = self.P @ v
            out.append(v.copy())
        return out

class MarkovTextGenerator:
    def __init__(self, P: np.ndarray, vocab):
        self.P = np.asarray(P, dtype=float)
        self.vocab = list(vocab)
        self.n = len(vocab)

    def generate(self, length=15, start_id=None):
        current = random.randrange(self.n) if start_id is None else int(start_id)
        result = [self.vocab[current]]

        for _ in range(length - 1):
            probs = self.P[:, current]
            s = probs.sum()
            if s <= 0:
                break
            nxt = np.random.choice(self.n, p=probs / s)
            result.append(self.vocab[nxt])
            current = nxt

        return " ".join(result)

DEFAULT_TEXT = (
    "In the quiet morning the wind moved through the trees and the street felt calm. "
    "A child laughed nearby, and a small bird hopped along the wall, waiting for crumbs. "
    "People walked slowly, thinking about ordinary plans and simple hopes for the day ahead."
)

class TextMarkovApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ex2: Word Transition Probabilities")
        self.geometry("720x760")

        self.vocab = []
        self.word_to_id = {}
        self.symbols = {}
        self.P = None

        self._build_ui()

    def _build_ui(self):
        self.input_box = self._section(
            "1) English text (~300 chars)",
            "Insert default text",
            self.fill_default,
            height=5
        )

        self.legend_box = self._section(
            "2) Build model + save JSON",
            "Compute transitions & save",
            self.compute_and_save,
            height=4,
            extra_box=True
        )

        self.matrix_box = self.extra_box  

        self.pred_box = self._section(
            "3) Predict distribution (5 steps)",
            "Run 5-step prediction",
            self.predict_steps,
            height=6
        )

        self.gen_box = self._section(
            "4) Generate new word sequence",
            "Generate text (15 words)",
            self.generate_text,
            height=4
        )
        self.gen_box.config(fg="blue", font=("Arial", 10, "bold"))

    def _section(self, title, button_label, button_cmd, height=4, extra_box=False):
        frame = tk.LabelFrame(self, text=title, padx=10, pady=10)
        frame.pack(fill="x", padx=10, pady=6)

        tk.Button(frame, text=button_label, command=button_cmd).pack(anchor="w")

        box = tk.Text(frame, width=85, height=height)
        box.pack(pady=6)

        if extra_box:
            self.extra_box = tk.Text(frame, width=85, height=6, bg="#f7f7f7")
            self.extra_box.pack(pady=4)

        return box

    def fill_default(self):
        self.input_box.delete("1.0", tk.END)
        self.input_box.insert(tk.END, DEFAULT_TEXT)

    def compute_and_save(self):
        raw = self.input_box.get("1.0", tk.END).strip()
        if not raw:
            messagebox.showwarning("Missing text", "Please enter some English text first.")
            return

        if len(raw) < 250 or len(raw) > 400:
            messagebox.showinfo(
                "Note",
                f"Text length is {len(raw)} characters. Task expects ~300 letters."
            )

        words = tokenize(raw)
        if len(words) < 2:
            messagebox.showerror("Too short", "Need at least two words to compute transitions.")
            return

        self.vocab, self.word_to_id, self.symbols = build_vocab(words)
        self.P = make_transition(words, self.word_to_id, len(self.vocab))

        save_json("text_matrix.json", raw, self.vocab, self.symbols, self.P)

        shown = dict(list(self.symbols.items())[:20])
        more = "" if len(self.symbols) <= 20 else f" ... (+{len(self.symbols)-20} more)"
        self.legend_box.delete("1.0", tk.END)
        self.legend_box.insert(tk.END, f"Saved to text_matrix.json\nSymbols (sample): {shown}{more}")

        self.matrix_box.delete("1.0", tk.END)
        for row in self.P:
            self.matrix_box.insert(tk.END, " ".join(f"{x:.2f}" for x in row) + "\n")

    def predict_steps(self):
        if self.P is None:
            messagebox.showwarning("No model", "Compute the matrix first.")
            return

        n = len(self.vocab)
        v0 = np.zeros(n, dtype=float)
        v0[0] = 1.0

        pred = DistributionPredictor(self.P)
        seq = pred.steps(v0, k=5)

        self.pred_box.delete("1.0", tk.END)
        self.pred_box.insert(tk.END, f"Start word: '{self.vocab[0]}'\n")
        for i, v in enumerate(seq, start=1):
            best = int(np.argmax(v))
            self.pred_box.insert(
                tk.END,
                f"t={i}: most likely '{self.vocab[best]}' with p={v[best]:.3f}\n"
            )

    def generate_text(self):
        if self.P is None:
            messagebox.showwarning("No model", "Compute the matrix first.")
            return

        gen = MarkovTextGenerator(self.P, self.vocab)
        out = gen.generate(length=15)
        self.gen_box.delete("1.0", tk.END)
        self.gen_box.insert(tk.END, out + " ...")


if __name__ == "__main__":
    app = TextMarkovApp()
    app.mainloop()
