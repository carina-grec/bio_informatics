#use the json file to create an engine that is able to use the transition probabilities in order to produce an output similar to the original text from which the training was made. create 2 separate applications namely one that produces DNA sequence and one that produces english text. use a gui interface for both. for the text i want to have a small window to see also the "encoded" with unique characters. how to make this enginge: you need to use the transition probabilities.: example you need 2 states A and B. The probability from A to A si 0.5 aand from A to B is 0.5, From B to B is 0.2. From B to A is 0.8 in the matrix we have 2 lines 0.5 0.5 and 0.2 0.8 these lines are 2 vectors. Lets take a unit = 10 letters. For A we will represent 5 letters and the rest of 5 letters to B. For vector B we will represent 8 letters A and 2 letters B we will use random pickup letters using the state machine. this is the simplified version

import json
import numpy as np
import random

DNA_STATES = ("A", "C", "G", "T")

def read_matrix_json(path="dna_matrix.json") -> np.ndarray:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "transition_matrix" in data:
        data = data["transition_matrix"]
    return np.asarray(data, dtype=float)

class MarkovEngine:
    def __init__(self, transition: np.ndarray, states=DNA_STATES):
        self.P = np.asarray(transition, dtype=float)
        self.states = list(states)
        self.n = len(self.states)

        if self.P.shape != (self.n, self.n):
            raise ValueError(f"Matrix must be {self.n}x{self.n}, got {self.P.shape}.")

    def _next_state_direct(self, current_idx: int) -> int:
        probs = self.P[:, current_idx]
        total = float(probs.sum())
        if total <= 0:
            return current_idx  # fallback: self-loop
        probs = probs / total
        return int(np.random.choice(self.n, p=probs))

    def _next_state_bucket(self, current_idx: int, unit: int = 10) -> int:
        probs = self.P[:, current_idx]
        total = float(probs.sum())
        if total <= 0:
            return current_idx

        probs = probs / total
        counts = [int(round(p * unit)) for p in probs]
        drift = unit - sum(counts)
        if drift != 0:
            k = int(np.argmax(probs))
            counts[k] += drift

        bucket = []
        for idx, c in enumerate(counts):
            bucket.extend([idx] * max(c, 0))
        if not bucket:
            return current_idx
        return random.choice(bucket)

    def generate(self, length: int = 50, start=None, method="direct", unit=10) -> str:
        if start is None:
            cur = random.randrange(self.n)
        else:
            cur = int(start)
        out = [self.states[cur]]
        stepper = self._next_state_direct if method == "direct" else (
            lambda i: self._next_state_bucket(i, unit=unit)
        )
        for _ in range(length - 1):
            cur = stepper(cur)
            out.append(self.states[cur])
        return "".join(out)

def main():
    try:
        P = read_matrix_json("dna_matrix.json")
        engine = MarkovEngine(P, DNA_STATES)

        print("DNA Synthesis")
        dna = engine.generate(length=50, method="bucket", unit=10)
        print(dna)
    except FileNotFoundError:
        print("Error: dna_matrix.json not found.")
    except ValueError as e:
        print(f"Bad matrix: {e}")

if __name__ == "__main__":
    main()
