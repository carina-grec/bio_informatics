'''
1. Take an arbitrary DNA sequence from the NCBI (National Center for Biotechnology), between 1000 and 3000 nucleotides (letters).
2. Use 5 restriction enzymes (enzyme name, recognized sequence, cleavage site):

EcoRI     	
5'GAATTC
3'CTTAAG
     
5'---G     AATTC---3'
3'---CTTAA     G---5'

BamHI     	
5'GGATCC
3'CCTAGG
     
5'---G     GATCC---3'
3'---CCTAG     G---5'

HindIII     	
5'AAGCTT
3'TTCGAA
     
5'---A     AGCTT---3'
3'---TTCGA     A---5'

TaqI     	
5'TCGA
3'AGCT
     
5'---T   CGA---3'
3'---AGC   T---5'

HaeIII*     	
5'GGCC
3'CCGG
     
5'---GG  CC---3'
3'---CC  GG---5'

Input of the implementation:
1. The recognized sequence for each restriction enzyme.
2. A DNA sequence to be digested.

Output of the implementation:
1. Number of cleavages for a each restriction enzyme.
2. Cleavage positions and length of fragments.
3. A simulation of the electrophoresis gel based on the number of restriction enzymes used.
'''
#Use the 10 influenza genomes from the file and use the restriction enzymes from your set to simulate the electrophoresis gel for these genomes. Eliminate all comunalities from the 10 electrophoresis gel simulations and amke one general electrophoresis gel that shows only the differences between these genomes.

import os
import math
import numpy as np
import matplotlib.pyplot as plt

def read_fasta_sequence(path):
    with open(path, "r") as f:
        lines = f.readlines()
    seq = "".join(line.strip() for line in lines if not line.startswith(">"))
    return seq.upper()

def digest_dna(dna_sequence, enzymes):
    digestion_results = {}

    for enzyme_name, recognition_seq in enzymes.items():
        cleavage_positions = []
        start = 0

        while True:
            pos = dna_sequence.find(recognition_seq, start)
            if pos == -1:
                break
            cleavage_positions.append(pos + len(recognition_seq) // 2)
            start = pos + 1

        fragments = []
        previous_position = 0
        for position in cleavage_positions:
            fragments.append(position - previous_position)
            previous_position = position
        fragments.append(len(dna_sequence) - previous_position)

        digestion_results[enzyme_name] = {
            "num_cleavages": len(cleavage_positions),
            "cleavage_positions": cleavage_positions,
            "fragment_lengths": fragments,
        }

    return digestion_results

def collect_combined_fragments(digestion_results_for_one_genome):
    combined = []
    for enz_name, res in digestion_results_for_one_genome.items():
        combined.extend(res["fragment_lengths"])
    return combined


def compute_unique_bands(fragments_by_genome, tolerance=10):
    genome_names = list(fragments_by_genome.keys())
    n_genomes = len(genome_names)

    all_entries = []
    for gname, lengths in fragments_by_genome.items():
        for L in lengths:
            all_entries.append((L, gname))

    if not all_entries:
        return {g: [] for g in genome_names}

    all_entries.sort(key=lambda x: x[0])

    clusters = []   
    current_cluster = [all_entries[0]]
    for (L, g) in all_entries[1:]:
        prev_L = current_cluster[-1][0]
        if abs(L - prev_L) <= tolerance:
            current_cluster.append((L, g))
        else:
            clusters.append(current_cluster)
            current_cluster = [(L, g)]
    clusters.append(current_cluster)

    common_entries = set()
    for cl in clusters:
        genomes_here = {g for (_, g) in cl}
        if len(genomes_here) == n_genomes:  
            for (L, g) in cl:
                common_entries.add((L, g))

    unique_by_genome = {g: [] for g in genome_names}
    for (L, g) in all_entries:
        if (L, g) not in common_entries:
            unique_by_genome[g].append(L)

    return unique_by_genome

def _length_to_row(L, rows, min_len, max_len):
    if max_len == min_len:
        return rows // 2
    log_min = math.log10(min_len)
    log_max = math.log10(max_len)
    logL = math.log10(L)
    frac = (logL - log_min) / (log_max - log_min)  
    row = (1 - frac) * (rows - 1)                  
    return int(round(row))


def plot_gel_image(digestion_like, rows=400, lane_width=40, lane_spacing=20,
                   band_thickness=6, filename="gel_simulation.png"):
 
    lane_names = list(digestion_like.keys())
    if not lane_names:
        print("No lanes to plot.")
        return

    n_lanes = len(lane_names)
    width = n_lanes * lane_width + (n_lanes - 1) * lane_spacing

    gel = np.zeros((rows, width))

    all_lengths = [
        L
        for v in digestion_like.values()
        for L in v["fragment_lengths"]
    ]
    if not all_lengths:
        print("No bands to plot.")
        return

    min_len = min(all_lengths)
    max_len = max(all_lengths)

    for i, name in enumerate(lane_names):
        lengths = digestion_like[name]["fragment_lengths"]
        lane_start = i * (lane_width + lane_spacing)
        lane_end = lane_start + lane_width

        for L in lengths:
            r = _length_to_row(L, rows, min_len, max_len)
            r_start = max(0, r - band_thickness // 2)
            r_end = min(rows, r_start + band_thickness)
            gel[r_start:r_end, lane_start:lane_end] = 1.0  

    gradient = np.linspace(0.2, 0.8, rows).reshape(-1, 1)
    gel = gradient + gel * 0.8

    plt.figure(figsize=(4, 6))
    plt.imshow(gel, aspect="auto", origin="upper")  
    plt.axis("off")
    plt.tight_layout(pad=0)
    plt.savefig(filename, bbox_inches="tight", pad_inches=0)
    plt.close()
    print(f"Saved gel image to {filename}")


if __name__ == "__main__":
    folder = "10 genomes"  
    genome_files = [
        f for f in os.listdir(folder)
        if f.lower().endswith((".fna", ".fasta", ".fa"))
    ]

    genomes = {}
    for fname in sorted(genome_files):
        path = os.path.join(folder, fname)
        seq = read_fasta_sequence(path)
        genomes[fname] = seq
        print(f"Loaded {fname}: {len(seq)} bp")

    enzymes = {
        "EcoRI":  "GAATTC",
        "BamHI":  "GGATCC",
        "HindIII": "AAGCTT",
        "TaqI":   "TCGA",
        "HaeIII": "GGCC",
    }

    all_digestions = {}  
    for gname, seq in genomes.items():
        dr = digest_dna(seq, enzymes)
        all_digestions[gname] = dr

    fragments_by_genome = {}
    for gname, dr in all_digestions.items():
        fragments_by_genome[gname] = collect_combined_fragments(dr)

    unique_bands = compute_unique_bands(fragments_by_genome, tolerance=10)

    diff_gel_dict = {
        gname: {"fragment_lengths": sorted(lengths, reverse=True)}
        for gname, lengths in unique_bands.items()
    }

    plot_gel_image(diff_gel_dict, filename="influenza_10_genomes_difference_gel.png")
