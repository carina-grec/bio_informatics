1241EA
Dan Maria-Andrada
Grec Carina Gabriela